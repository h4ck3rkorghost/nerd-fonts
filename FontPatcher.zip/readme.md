
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 50e0f8247ba0249a938c7e98617a41b81658bbfa
        Author: Finii <Finii@users.noreply.github.com>
        Date:   Tue Feb 21 14:25:33 2023 +0000
        
            [ci] Update FontPatcher.zip
